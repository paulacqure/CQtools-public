﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileHeaderHandler : IBinaryReadable
  {
    protected PrefetchFileHeader Item { get; set; }

    public PrefetchFileHeaderHandler(PrefetchFileHeader item)
    {
      Item = item;
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      Item.Version = reader.ReadUInt32();
      Item.Signature = reader.ReadUInt32();
      Item.Unknown0 = reader.ReadUInt32();
      Item.FileSize = reader.ReadUInt32();
      byte[] execNameBytes = new byte[60];
      reader.Read(execNameBytes, 0, 60);

      int counter = 0;
      string tempString = string.Empty;
      char tempChar = char.MaxValue;
      int numZeroes = 0;
      do
      {
        tempChar = (char)execNameBytes[counter++];
        if (tempChar == 0) numZeroes++;
        else
        {
          numZeroes = 0;
          tempString += tempChar;
        }
      }
      while (numZeroes < 3);

      Item.ExecutableName = tempString;
      Item.Rawhash = new byte[4];
      reader.Read(Item.Rawhash, 0, 4);
      Item.Hash = BitConverter.ToString(Item.Rawhash).Replace("-", "");
      Item.Unknown1 = reader.ReadUInt32();
    }
  }

}
