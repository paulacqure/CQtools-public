﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  internal interface IBinaryReadable
  {
    void ReadFrom(BinaryReader reader);
  }
}
