﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileVolumeInformation
  {
    public UInt32 VolPathOffset { get; set; }
    public UInt32 VolPathLength { get; set; }
    public DateTime VolCreationTime { get; set; }
    public UInt32 VolSerialNumber { get; set; }
    public UInt32 FileRefOffset { get; set; }
    public UInt32 FileRefCount { get; set; }
    public UInt32 DirStringsOffset { get; set; }
    public UInt32 DirStringsCount { get; set; }
    public byte[] Unknown0 { get; set; }
    public string VolName { get; set; }
    public List<PrefetchFileDirectoryString> DirectoryStrings { get; set; }
    public PrefetchFileVolumesInformation Parent { get; set; }

    public PrefetchFileVolumeInformation(PrefetchFileVolumesInformation item)
    {
      this.Parent = item;
    }
  }
}
