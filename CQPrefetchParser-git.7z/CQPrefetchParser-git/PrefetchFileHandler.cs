﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileWinXPHandler : PrefetchFileHandler
  {
    public PrefetchFileWinXPHandler(PrefetchFile item) : base(item)
    {
    }

    public override void ReadFrom(BinaryReader reader)
    {
      PrefetchFileHeaderHandler pfFHH = new PrefetchFileHeaderHandler(Item.Header);
      pfFHH.ReadFrom(reader);

      PrefetchFileFileInformationHandler pfFFIH = new PrefetchFileFileInformationWinXPHandler(Item.FileInformation);
      pfFFIH.ReadFrom(reader);

      PrefetchFileMetricsArrayHandler pfMAH = new PrefetchFileMetricsArrayWinXPHandler(Item.MetricsArray);
      pfMAH.ReadFrom(reader);

      PrefetchFileTraceChainsArrayHandler pfTCAH = new PrefetchFileTraceChainsArrayWinXPHandler(Item.TraceChainsArray);
      pfTCAH.ReadFrom(reader);

      PrefetchFileVolumesInformationHandler pfVIH = new PrefetchFileVolumesInformationWinXPHandler(Item.VolumesInformation);
      pfVIH.ReadFrom(reader);

      reader.BaseStream.Position = Item.FileInformation.FilenameStringsOffset;

      PrefetchFileFileNamesHandler pfFNH = new PrefetchFileFileNamesWinXPHandler(Item.FileNames);
      pfFNH.ReadFrom(reader);
    }
  }
  class PrefetchFileVistaOrSevenHandler : PrefetchFileWinXPHandler
  {
    public PrefetchFileVistaOrSevenHandler(PrefetchFile item) : base(item)
    {
    }

    public override void ReadFrom(BinaryReader reader)
    {
      PrefetchFileHeaderHandler pfFHH = new PrefetchFileHeaderHandler(Item.Header);
      pfFHH.ReadFrom(reader);

      PrefetchFileFileInformationHandler pfFFIH = new PrefetchFileFileInformationVistaOrSevenHandler(Item.FileInformation);
      pfFFIH.ReadFrom(reader);

      PrefetchFileMetricsArrayHandler pfMAH = new PrefetchFileMetricsArrayVistaOrSevenHandler(Item.MetricsArray);
      pfMAH.ReadFrom(reader);

      PrefetchFileTraceChainsArrayHandler pfTCAH = new PrefetchFileTraceChainsArrayVistaOrSevenHandler(Item.TraceChainsArray);
      pfTCAH.ReadFrom(reader);

      PrefetchFileVolumesInformationHandler pfVIH = new PrefetchFileVolumesInformationVistaOrSevenHandler(Item.VolumesInformation);
      pfVIH.ReadFrom(reader);

      reader.BaseStream.Position = Item.FileInformation.FilenameStringsOffset;

      PrefetchFileFileNamesHandler pfFNH = new PrefetchFileFileNamesVistaOrSevenHandler(Item.FileNames);
      pfFNH.ReadFrom(reader);
    }
    //protected override void ReadFileInformation(BinaryReader reader)
    //{
    //  //TODO
    //}

    //protected override void ReadMetricsArray(BinaryReader reader)
    //{
    //  //reader.BaseStream.Position = metricsOffset;
    //  //base.ReadMetricsArray(reader);
    //}

    //protected override void ReadVolumeInformation(BinaryReader reader)
    //{
    //  //TODO
    //}
  }
  class PrefetchFileWin8Handler : PrefetchFileVistaOrSevenHandler
  {
    public PrefetchFileWin8Handler(PrefetchFile item) : base(item)
    {
    }

    public override void ReadFrom(BinaryReader reader)
    {
      PrefetchFileHeaderHandler pfFHH = new PrefetchFileHeaderHandler(Item.Header);
      pfFHH.ReadFrom(reader);

      PrefetchFileFileInformationHandler pfFFIH = new PrefetchFileFileInformationWin8Handler(Item.FileInformation);
      pfFFIH.ReadFrom(reader);

      PrefetchFileMetricsArrayHandler pfMAH = new PrefetchFileMetricsArrayWin8Handler(Item.MetricsArray);
      pfMAH.ReadFrom(reader);

      PrefetchFileTraceChainsArrayHandler pfTCAH = new PrefetchFileTraceChainsArrayWin8Handler(Item.TraceChainsArray);
      pfTCAH.ReadFrom(reader);

      PrefetchFileVolumesInformationHandler pfVIH = new PrefetchFileVolumesInformationWin8Handler(Item.VolumesInformation);
      pfVIH.ReadFrom(reader);

      reader.BaseStream.Position = Item.FileInformation.FilenameStringsOffset;

      PrefetchFileFileNamesHandler pfFNH = new PrefetchFileFileNamesWin8Handler(Item.FileNames);
      pfFNH.ReadFrom(reader);
    }
    //protected override void ReadFileInformation(BinaryReader reader)
    //{
    //  //TODO
    //}
  }

  class PrefetchFileWin10Handler : PrefetchFileWin8Handler
  {
    public PrefetchFileWin10Handler(PrefetchFile item) : base(item)
    {
    }

    public override void ReadFrom(BinaryReader reader)
    {
      PrefetchFileHeaderHandler pfFHH = new PrefetchFileHeaderHandler(Item.Header);
      pfFHH.ReadFrom(reader);

      PrefetchFileFileInformationHandler pfFFIH = new PrefetchFileFileInformationWin10Handler(Item.FileInformation);
      pfFFIH.ReadFrom(reader);

      PrefetchFileMetricsArrayHandler pfMAH = new PrefetchFileMetricsArrayWin10Handler(Item.MetricsArray);
      pfMAH.ReadFrom(reader);

      PrefetchFileTraceChainsArrayHandler pfTCAH = new PrefetchFileTraceChainsArrayWin10Handler(Item.TraceChainsArray);
      pfTCAH.ReadFrom(reader);

      PrefetchFileVolumesInformationHandler pfVIH = new PrefetchFileVolumesInformationWin10Handler(Item.VolumesInformation);
      pfVIH.ReadFrom(reader);

      reader.BaseStream.Position = Item.FileInformation.FilenameStringsOffset;

      PrefetchFileFileNamesHandler pfFNH = new PrefetchFileFileNamesWin10Handler(Item.FileNames);
      pfFNH.ReadFrom(reader);
    }
    //protected override void ReadTraceChainsArray(BinaryReader reader)
    //{
    //  //TODO
    //}

    //protected override void ReadVolumeInformation(BinaryReader reader)
    //{
    //  //TODO
    //}
  }
  class PrefetchFileHandler : IBinaryReadable
  {
    protected PrefetchFile Item { get; set; }


    protected BinaryReader reader = null;

    static internal PrefetchFileHandler GetPrefetchFileHandler(PrefetchFile item, BinaryReader br)
    {
      long currPos = br.BaseStream.Position;
      UInt32 version = br.ReadUInt32();
      br.BaseStream.Position = currPos;
      PrefetchFileHandler result = null;
      switch (version)
      {
        case 17:
          result = new PrefetchFileWinXPHandler(item);
          break;
        case 23:
          result = new PrefetchFileVistaOrSevenHandler(item);
          break;
        case 26:
          result = new PrefetchFileWin8Handler(item);
          break;
        case 30:
          result = new PrefetchFileWin10Handler(item);
          break;
        default:
          break;
      }
      if (result != null) result.reader = br;
      return result;
    }

    protected PrefetchFileHandler(PrefetchFile item)
    {
      this.Item = item;
      Item.Header = new PrefetchFileHeader(Item);
      Item.FileInformation = new PrefetchFileFileInformation(Item);
      Item.MetricsArray = new PrefetchFileMetricsArray(Item);
      Item.TraceChainsArray = new PrefetchFileTraceChainsArray(Item);
      Item.VolumesInformation = new PrefetchFileVolumesInformation(Item);
      Item.FileNames = new PrefetchFileFileNames(Item);
      //Header = new PrefetchFileHeaderHandler(Item.Header);
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      if (reader == null) return;

      PrefetchFileHeaderHandler pfFHH = new PrefetchFileHeaderHandler(Item.Header);
      pfFHH.ReadFrom(reader);

      PrefetchFileFileInformationHandler pfFFIH = new PrefetchFileFileInformationHandler(Item.FileInformation);
      pfFFIH.ReadFrom(reader);

      PrefetchFileMetricsArrayHandler pfMAH = new PrefetchFileMetricsArrayHandler(Item.MetricsArray);
      pfMAH.ReadFrom(reader);

      PrefetchFileTraceChainsArrayHandler pfTCAH = new PrefetchFileTraceChainsArrayHandler(Item.TraceChainsArray);
      pfTCAH.ReadFrom(reader);

      PrefetchFileVolumesInformationHandler pfVIH = new PrefetchFileVolumesInformationHandler(Item.VolumesInformation);
      pfVIH.ReadFrom(reader);

      reader.BaseStream.Position = Item.FileInformation.FilenameStringsOffset;

      PrefetchFileFileNamesHandler pfFNH = new PrefetchFileFileNamesHandler(Item.FileNames);
      pfFNH.ReadFrom(reader);

    }

    //protected virtual void ReadGetFilenameStrings(BinaryReader reader)
    //{
    //  //TODO
    //}

    //protected virtual void ReadDirectoryStrings(BinaryReader reader)
    //{
    //  //TODO
    //}

    //protected virtual void ReadGetTimeStamps(BinaryReader reader)
    //{
    //  //TODO
    //}

    //protected virtual void ReadVolumeInformation(BinaryReader reader)
    //{
    //  throw new NotImplementedException();
    //}

    //protected virtual void ReadTraceChainsArray(BinaryReader reader)
    //{
    //}

    //protected virtual void ReadMetricsArray(BinaryReader reader)
    //{
    //}


    //protected virtual void ReadFileInformation(BinaryReader reader)
    //{
    //}

    //protected virtual void ReadHeaderSection(BinaryReader reader)
    //{
    //}
  }
}
