﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileHeader
  {
    public UInt32 Version { get; set; }
    public UInt32 Signature { get; set; }
    public UInt32 Unknown0 { get; set; }
    public UInt32 FileSize { get; set; }
    public string ExecutableName { get; set; }
    public byte[] Rawhash { get; set; }
    public string Hash { get; set; }
    public uint Unknown1 { get; set; }
    public PrefetchFile Parent { get; set; }

    public PrefetchFileHeader(PrefetchFile item)
    {
      Parent = item;
    }

  }
}
