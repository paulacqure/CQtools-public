﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileFileInformationWinXPHandler : PrefetchFileFileInformationHandler
  {
    public PrefetchFileFileInformationWinXPHandler(PrefetchFileFileInformation item) : base(item)
    {
      FIu0size = 0;
      FIu1size = 16;
      FIu2size = 4;
      FIlastRunTimeSize = 1;
    }
  }
  class PrefetchFileFileInformationVistaOrSevenHandler : PrefetchFileFileInformationWinXPHandler
  {
    public PrefetchFileFileInformationVistaOrSevenHandler(PrefetchFileFileInformation item) : base(item)
    {
      FIu0size = 8;
      FIu1size = 16;
      FIu2size = 84;
      FIlastRunTimeSize = 1;
    }
  }
  class PrefetchFileFileInformationWin8Handler : PrefetchFileFileInformationVistaOrSevenHandler
  {
    public PrefetchFileFileInformationWin8Handler(PrefetchFileFileInformation item) : base(item)
    {
      FIu0size = 8;
      FIu1size = 16;
      FIu2size = 96;
      FIlastRunTimeSize = 8;
    }
  }
  class PrefetchFileFileInformationWin10Handler : PrefetchFileFileInformationWin8Handler
  {
    public PrefetchFileFileInformationWin10Handler(PrefetchFileFileInformation item) : base(item)
    {
      FIu0size = 8;
      FIu1size = 8;
      FIu2size = 96;
      FIlastRunTimeSize = 8;
    }
  }
  class PrefetchFileFileInformationHandler : IBinaryReadable
  {
    protected int FIu0size = 0;
    protected int FIu1size = 1;
    protected int FIu2size = 16;
    protected int FIlastRunTimeSize = 4;

    protected PrefetchFileFileInformation Item { get; set; }


    public PrefetchFileFileInformationHandler(PrefetchFileFileInformation item)
    {
      Item = item;
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      Item.MetricsOffset = reader.ReadUInt32();
      Item.MetricsCount = reader.ReadUInt32();
      Item.TraceChainsOffset = reader.ReadUInt32();
      Item.TraceChainsCount = reader.ReadUInt32();
      Item.FilenameStringsOffset = reader.ReadUInt32();
      Item.FilenameStringsSize = reader.ReadUInt32();
      Item.VolumesInformationOffset = reader.ReadUInt32();
      Item.VolumesCount = reader.ReadUInt32();
      Item.VolumesInformationSize = reader.ReadUInt32();

      Item.UnknownFI0 = new byte[FIu0size];
      reader.Read(Item.UnknownFI0, 0, FIu0size);

      Item.LastRunTime = new Int64[FIlastRunTimeSize];
      for (int i = 0; i < FIlastRunTimeSize; i++)
        Item.LastRunTime[i] = reader.ReadInt64();
      Item.LastRunTimeDT = new DateTime[FIlastRunTimeSize];
      for (int i = 0; i < FIlastRunTimeSize; i++)
        Item.LastRunTimeDT[i] = DateTime.FromBinary((long)Item.LastRunTime[i]).AddYears(1600);

      Item.UnknownFI1 = new byte[FIu1size];
      reader.Read(Item.UnknownFI1, 0, FIu1size);
      Item.RunCount = reader.ReadUInt32();
      Item.UnknownFI2 = new byte[FIu2size];
      reader.Read(Item.UnknownFI2, 0, FIu2size);
    }
  }

}
