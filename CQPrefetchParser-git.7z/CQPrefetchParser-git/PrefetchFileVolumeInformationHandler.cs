﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{  class PrefetchFileVolumeInformationWinXPHandler : PrefetchFileVolumeInformationHandler
  {
    public PrefetchFileVolumeInformationWinXPHandler(PrefetchFileVolumeInformation item) : base(item)
    {
      u0size = 4; totalSize = 40;
    }
  }
  class PrefetchFileVolumeInformationVistaOrSevenHandler : PrefetchFileVolumeInformationWinXPHandler
  {
    public PrefetchFileVolumeInformationVistaOrSevenHandler(PrefetchFileVolumeInformation item) : base(item)
    {
      u0size = 68; totalSize = 104;
    }
  }
  class PrefetchFileVolumeInformationWin8Handler : PrefetchFileVolumeInformationVistaOrSevenHandler
  {
    public PrefetchFileVolumeInformationWin8Handler(PrefetchFileVolumeInformation item) : base(item)
    {
    }
  }
  class PrefetchFileVolumeInformationWin10Handler : PrefetchFileVolumeInformationWin8Handler
  {
    public PrefetchFileVolumeInformationWin10Handler(PrefetchFileVolumeInformation item) : base(item)
    {
      u0size = 60; totalSize = 96;
    }
  }
  class PrefetchFileVolumeInformationHandler : IBinaryReadable
  {
    protected int u0size;
    protected int totalSize;

    PrefetchFileVolumeInformation Item { get; set; }
    public PrefetchFileVolumeInformationHandler(PrefetchFileVolumeInformation item)
    {
      Item = item;
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
    }

    public virtual void ReadFrom(BinaryReader reader, int counter)
    {
      Item.VolPathOffset = reader.ReadUInt32();
      Item.VolPathLength = reader.ReadUInt32();
      Item.VolCreationTime = DateTime.FromBinary((long)reader.ReadUInt64()).AddYears(1600);
      Item.VolSerialNumber = reader.ReadUInt32();
      Item.FileRefOffset = reader.ReadUInt32();
      Item.FileRefCount = reader.ReadUInt32();
      Item.DirStringsOffset = reader.ReadUInt32();
      Item.DirStringsCount = reader.ReadUInt32();
      Item.Unknown0 = new byte[u0size];
      reader.BaseStream.Position = Item.Parent.Parent.FileInformation.VolumesInformationOffset + Item.VolPathOffset;

      PrefetchFileDirectoryString pfds = new PrefetchFileDirectoryString(Item);
      PrefetchFileDirectoryStringHandler pfdsh = new PrefetchFileDirectoryStringHandler(pfds);
      pfdsh.ReadFrom(reader);

      reader.BaseStream.Position = Item.Parent.Parent.FileInformation.VolumesInformationOffset + Item.VolPathOffset;
      Item.VolName = Utils.ReadNullTerminatedUnicodeString(reader);
      reader.BaseStream.Position = Item.Parent.Parent.FileInformation.VolumesInformationOffset + totalSize * counter;
    }
  }

}
