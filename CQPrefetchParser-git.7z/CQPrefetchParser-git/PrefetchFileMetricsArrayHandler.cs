﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileMetricsArrayWinXPHandler : PrefetchFileMetricsArrayHandler
  {
    public PrefetchFileMetricsArrayWinXPHandler(PrefetchFileMetricsArray item) : base(item)
    {
      MAu0size = 2;
      MAfrsize = 0;
    }
  }
  class PrefetchFileMetricsArrayVistaOrSevenHandler : PrefetchFileMetricsArrayWinXPHandler
  {
    public PrefetchFileMetricsArrayVistaOrSevenHandler(PrefetchFileMetricsArray item) : base(item)
    {
      MAu0size = 3;
      MAfrsize = 1;
    }
    public override void ReadFrom(BinaryReader reader)
    {
      reader.BaseStream.Position = Item.Parent.FileInformation.MetricsOffset;
      base.ReadFrom(reader);
    }
  }
  class PrefetchFileMetricsArrayWin8Handler : PrefetchFileMetricsArrayVistaOrSevenHandler
  {
    public PrefetchFileMetricsArrayWin8Handler(PrefetchFileMetricsArray item) : base(item)
    {
    }
  }
  class PrefetchFileMetricsArrayWin10Handler : PrefetchFileMetricsArrayWin8Handler
  {
    public PrefetchFileMetricsArrayWin10Handler(PrefetchFileMetricsArray item) : base(item)
    {
    }
  }
  class PrefetchFileMetricsArrayHandler : IBinaryReadable
  {
    protected int MAu0size = 2;
    protected int MAfrsize = 0;

    protected PrefetchFileMetricsArray Item { get; set; }

    public PrefetchFileMetricsArrayHandler(PrefetchFileMetricsArray item)
    {
      Item = item;
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      Item.UnknownMA0 = new uint[MAu0size];
      for (int i = 0; i < MAu0size; i++)
        Item.UnknownMA0[i] = reader.ReadUInt32();
      Item.FilenameOffset = reader.ReadUInt32();
      Item.FilenameLength = reader.ReadUInt32();
      Item.UnknownMA1 = reader.ReadUInt32();
      Item.FileReference = new UInt64[MAfrsize];
      for (int i = 0; i < MAfrsize; i++)
        Item.FileReference[i] = reader.ReadUInt64();

    }
  }
}
