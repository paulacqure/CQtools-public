﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileTraceChainsArray
  {
    public PrefetchFileTraceChainsArray(PrefetchFile item)
    {
      this.Parent = item;
    }

    public byte[] TCAunknown0 { get; set; }
    public PrefetchFile Parent { get; set; }

  }
}
