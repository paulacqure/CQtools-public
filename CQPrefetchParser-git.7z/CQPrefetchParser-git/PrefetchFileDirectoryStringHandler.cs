﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileDirectoryStringHandler : IBinaryReadable
  {
    PrefetchFileDirectoryString Item { get; set; }
    public PrefetchFileDirectoryStringHandler(PrefetchFileDirectoryString item)
    {
      Item = item;
      Item.Parent.DirectoryStrings = new List<PrefetchFileDirectoryString>();
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      reader.BaseStream.Position = Item.Parent.Parent.Parent.FileInformation.VolumesInformationOffset + Item.Parent.DirStringsOffset;
      PrefetchFileDirectoryString tempPFDS = null;

      for (int i = 0; i < Item.Parent.DirStringsCount; i++)
      {
        tempPFDS = new PrefetchFileDirectoryString(Item.Parent);
        tempPFDS.StringLength = (uint)reader.ReadUInt16() + 2;
        tempPFDS.Dir = Utils.ReadNullTerminatedUnicodeString(reader);

        Item.Parent.DirectoryStrings.Add(tempPFDS);
      }
    }
  }
}
