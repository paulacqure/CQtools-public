﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileVolumesInformation
  {
    public PrefetchFileVolumesInformation(PrefetchFile item)
    {
      this.Parent = item;
    }

    public List<PrefetchFileVolumeInformation> Volumes { get; set; }
    public PrefetchFile Parent { get; set; }
  }
}
