﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  internal class PrefetchFile
  {
    public PrefetchFileHeader Header { get; set; }
    public PrefetchFileFileInformation FileInformation { get; set; }
    public PrefetchFileMetricsArray MetricsArray { get; set; }
    public PrefetchFileTraceChainsArray TraceChainsArray { get; set; }
    public PrefetchFileVolumesInformation VolumesInformation { get; set; }
    public PrefetchFileFileNames FileNames { get; set; }
    public bool Compressed { get; set; }
    internal static PrefetchFile Load(byte[] fileData)
    {
      bool compressed = false;
      byte[] data = Preload(fileData, out compressed);
      PrefetchFile result = new PrefetchFile();
      result.Compressed = compressed;
      using (MemoryStream ms = new MemoryStream(data))
      {
        using (BinaryReader binaryReader = new BinaryReader(ms))
        {
          PrefetchFileHandler reader = PrefetchFileHandler.GetPrefetchFileHandler(result, binaryReader);
          reader.ReadFrom(binaryReader);
          return result;
        }
      }

    }
    internal static PrefetchFile Load(string fileName)
    {
      string fullFileName = Path.GetFullPath(fileName);
      return Load(File.ReadAllBytes(fileName));
    }

    private static byte[] Preload(byte[] data, out bool compressed)
    {
      if (IsCompressed(data))
      {
        compressed = true;
        return Decompress(data);
      }
      else
      {
        compressed = false;
        return data;
      }
    }

    internal static void Decompress(string fileIn, string fileOut)
    {
      byte[] inData = File.ReadAllBytes(Path.GetFullPath(fileIn));
      byte[] outData = null;
      if (IsCompressed(inData))
      {
        outData = Decompress(inData);
      }
      if (outData == null) outData = inData;

      string fileOutFull = Path.GetFullPath(fileOut);
      try
      {
        File.WriteAllBytes(fileOutFull, outData);
        Console.WriteLine("File successfully decompressed!");
      }
      catch (Exception ex)
      {
        Console.WriteLine($"Problem writing data to the file {fileOutFull}");
        Console.WriteLine(ex.Message);
      }
    }

    private static byte[] Decompress(byte[] data)
    {
      return PrefetchFileCompressed.Decompress(data);
    }

    private static bool IsCompressed(byte[] data)
    {
      if (data != null && data.Length > 3 && data[0] == 0x4d && data[1] == 0x41 && data[2] == 0x4d) //"MAM" file, decompress
        return true;
      else
        return false;
    }
  }
}
