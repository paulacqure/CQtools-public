﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileTraceChainsArrayWinXPHandler : PrefetchFileTraceChainsArrayHandler
  {
    public PrefetchFileTraceChainsArrayWinXPHandler(PrefetchFileTraceChainsArray item) : base(item)
    {
    }

    //public override void ReadFrom(BinaryReader reader)
    //{
    //  //reader.BaseStream.Position += 12;
    //  //base.ReadFrom(reader);
    //}
  }
  class PrefetchFileTraceChainsArrayVistaOrSevenHandler : PrefetchFileTraceChainsArrayWinXPHandler
  {
    public PrefetchFileTraceChainsArrayVistaOrSevenHandler(PrefetchFileTraceChainsArray item) : base(item)
    {
    }
  }
  class PrefetchFileTraceChainsArrayWin8Handler : PrefetchFileTraceChainsArrayVistaOrSevenHandler
  {
    public PrefetchFileTraceChainsArrayWin8Handler(PrefetchFileTraceChainsArray item) : base(item)
    {
    }
  }
  class PrefetchFileTraceChainsArrayWin10Handler : PrefetchFileTraceChainsArrayWin8Handler
  {
    public PrefetchFileTraceChainsArrayWin10Handler(PrefetchFileTraceChainsArray item) : base(item)
    {
      TCAu0size = 8;
    }
  }
  class PrefetchFileTraceChainsArrayHandler : IBinaryReadable
  {
    protected int TCAu0size = 12;
    protected byte[] TCAunknown0 = null;
    protected PrefetchFileTraceChainsArray Item { get; set; }

    public PrefetchFileTraceChainsArrayHandler(PrefetchFileTraceChainsArray item)
    {
      Item = item;
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      Item.TCAunknown0 = new byte[TCAu0size];
      reader.Read(Item.TCAunknown0, 0, TCAu0size);
    }
  }
}
