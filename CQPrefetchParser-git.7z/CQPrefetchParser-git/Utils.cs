﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class Utils
  {
    public static string ReadNullTerminatedUnicodeString(BinaryReader reader)
    {
      string tempString = string.Empty;
      char tempChar = char.MaxValue;
      int numZeroes = 0;
      do
      {
        tempChar = (char)reader.ReadByte();
        if (tempChar == 0) numZeroes++;
        else
        {
          numZeroes = 0;
          tempString += tempChar;
        }
      }
      while (numZeroes < 3);

      return tempString;
    }
  }
}
