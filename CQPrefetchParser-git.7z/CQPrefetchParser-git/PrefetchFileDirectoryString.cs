﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileDirectoryString
  {
    public UInt32 StringLength { get; set; }
    public string Dir { get; set; }
    public PrefetchFileVolumeInformation Parent { get; set; }

    public PrefetchFileDirectoryString(PrefetchFileVolumeInformation item)
    {
      Parent = item;
    }
  }
}
