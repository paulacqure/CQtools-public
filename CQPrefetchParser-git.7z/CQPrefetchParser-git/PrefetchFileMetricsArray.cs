﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileMetricsArray
  {
    public PrefetchFileMetricsArray(PrefetchFile item)
    {
      this.Parent = item;
    }

    public UInt32[] UnknownMA0 { get; set; }
    public UInt32 UnknownMA1 { get; set; }
    public UInt32 FilenameOffset { get; set; }
    public UInt32 FilenameLength { get; set; }
    public UInt32 UnknownMA2 { get; set; }
    public UInt64[] FileReference { get; set; }
    public PrefetchFile Parent { get; set; }

  }
}
