﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileFileInformation
  {
    public PrefetchFileFileInformation(PrefetchFile item)
    {
      this.Parent = item;
    }

    public UInt32 MetricsOffset { get; set; }
    public UInt32 MetricsCount { get; set; }
    public UInt32 TraceChainsOffset { get; set; }
    public UInt32 TraceChainsCount { get; set; }
    public UInt32 FilenameStringsOffset { get; set; }
    public UInt32 FilenameStringsSize { get; set; }
    public UInt32 VolumesInformationOffset { get; set; }
    public UInt32 VolumesCount { get; set; }
    public UInt32 VolumesInformationSize { get; set; }
    public byte[] UnknownFI0 { get; set; }
    public Int64[] LastRunTime { get; set; }
    public DateTime[] LastRunTimeDT { get; set; }
    public byte[] UnknownFI1 { get; set; }
    public UInt32 RunCount { get; set; }
    public byte[] UnknownFI2 { get; set; }
    public PrefetchFile Parent { get; set; }

  }
}
