﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NDesk.Options;

namespace CQPrefetchParser
{
  class Program
  {
    static void Main(string[] args)
    {
      CommandLineArguments arguments = new CommandLineArguments();
      arguments.Parse(args);

      if (arguments.Help)
      {
        arguments.ShowHelp();
        return;
      }

      Program p = new Program();

      if (arguments.Analyze)
      {
        if (!string.IsNullOrEmpty(arguments.OUTItem))
        {
          Console.WriteLine("No need to specify /out item, omitting.");
        }
        if (!string.IsNullOrEmpty(arguments.PFFile))
        {
          try
          {
            p.AnalyzeFile(arguments.PFFile);
          }
          catch (Exception ex)
          {
            Console.WriteLine($"Something went wrong: {ex.Message}");
          }
        }

        if (!string.IsNullOrEmpty(arguments.PFDir))
        {
          if (arguments.Sort)
          {
            try
            {
              p.AnalyzeDirectoryAndSortByDate(arguments.PFDir);
            }
            catch (Exception ex)
            {
              Console.WriteLine($"Something went wrong: {ex.Message}");
            }
          }
          else
          {
            try
            {
              p.AnalyzeDirectory(arguments.PFDir);
            }
            catch (Exception ex)
            {
              Console.WriteLine($"Something went wrong: {ex.Message}");
            }
          }
        }
      }
      if (arguments.Decompress)
      {
        if (!string.IsNullOrEmpty(arguments.PFFile))
        {
          try
          {
            p.DecompressFile(arguments.PFFile, arguments.OUTItem);
          }
          catch (Exception ex)
          {
            Console.WriteLine($"Something went wrong: {ex.Message}");
          }
        }

        if (!string.IsNullOrEmpty(arguments.PFDir))
        {
          try
          {
            p.DecompressDirectory(arguments.PFDir, arguments.OUTItem);
          }
          catch (Exception ex)
          {
            Console.WriteLine($"Something went wrong: {ex.Message}");
          }
        }
      }

    }

    private void DecompressDirectory(string prefetchDir, string dirOut)
    {
      Console.WriteLine($"Decompressing directory: {Path.GetFullPath(prefetchDir)} to {Path.GetFullPath(dirOut)}");
      if (!Directory.Exists(dirOut))
      {
        Console.WriteLine("Check if the output directory exists and try again.");
        return;
      }
      var dirInfo = new DirectoryInfo(prefetchDir);
      foreach (var file in dirInfo.GetFiles("*.pf"))
      {
        string outFile = Path.Combine(Path.GetFullPath(dirOut), $"{file.Name}.{Guid.NewGuid().ToString()}");
        try
        {
          DecompressFile(file.FullName, outFile);
        }
        catch (Exception ex)
        {
          Console.WriteLine($"There's a problem decompressing the file (maybe corrupt? missing ntdll entries?): {Path.GetFullPath(file.FullName)}");
          Console.WriteLine($"Something went wrong: {ex.Message}");
        }
      }

    }

    private void DecompressFile(string prefetchFile, string outFile)
    {
      Console.WriteLine($"Decompressing file: {prefetchFile} to {outFile}");
      PrefetchFile.Decompress(prefetchFile, outFile);
    }
    private void AnalyzeDirectory(string prefetchDir)
    {
      foreach (var file in Directory.GetFiles(prefetchDir, "*.pf"))
      {
        try
        {
          AnalyzeFile(file);
        }
        catch (Exception ex)
        {
          Console.WriteLine($"The file seems to be corrupt: {Path.GetFullPath(file)}");
          Console.WriteLine($"Something went wrong: {ex.Message}");
        }
      }
    }

    SortedDictionary<DateTime, string> runDateTimes = new SortedDictionary<DateTime, string>();

    private void AnalyzeDirectoryAndSortByDate(string prefetchDir)
    {
      foreach (var file in Directory.GetFiles(prefetchDir, "*.pf"))
      {
        try
        {
          AnalyzeFileAndSortByDate(file);
          
        }
        catch (Exception ex)
        {
          Console.WriteLine($"The file seems to be corrupt: {Path.GetFullPath(file)}");
          Console.WriteLine($"Something went wrong: {ex.Message}");
        }
      }
      foreach(var vk in runDateTimes)
      {
        Console.WriteLine($"{vk.Key};{vk.Value}");
      }
    }

    private void AnalyzeFileAndSortByDate(string prefetchFile)
    {
      PrefetchFile pf = PrefetchFile.Load(prefetchFile);

      //Console.WriteLine($"File: {Path.GetFullPath(prefetchFile)}");
      //Console.WriteLine("Prefetch file is{0}compressed", (pf.Compressed) ? " " : " not ");

      //Console.WriteLine($"Executable name: {pf.Header.ExecutableName}");
      //Console.WriteLine();
      //Console.WriteLine($"Run count: {pf.FileInformation.RunCount}");
      //Console.WriteLine($"Last executed:");
      for (int i = 0; i < pf.FileInformation.LastRunTime.Length && i < pf.FileInformation.RunCount; i++)
      {
        if(!runDateTimes.ContainsKey(pf.FileInformation.LastRunTimeDT[i]))
          runDateTimes.Add(pf.FileInformation.LastRunTimeDT[i], pf.Header.ExecutableName);
        //Console.WriteLine($"  {pf.FileInformation.LastRunTimeDT[i]}");
      }

      //Console.WriteLine();
      //Console.WriteLine("File Reference:");
      //for (int i = 0; i < pf.MetricsArray.FileReference.Length; i++)
      //  Console.WriteLine($"{pf.MetricsArray.FileReference[i]:X}");

      //Console.WriteLine();
      //Console.WriteLine("Volume information:");
      //for (int i = 0; i < pf.FileInformation.VolumesCount; i++)
      //{
      //  Console.WriteLine($" Volume name: {pf.VolumesInformation.Volumes[i].VolName}");
      //  Console.WriteLine($" Creation date: {pf.VolumesInformation.Volumes[i].VolCreationTime}");
      //  Console.WriteLine($" Serial number: {pf.VolumesInformation.Volumes[i].VolSerialNumber:X}");
      //  Console.WriteLine();
      //}

      //Console.WriteLine("Directory strings:");
      //for (int i = 0; i < pf.FileInformation.VolumesCount; i++)
      //{
      //  for (int j = 0; j < pf.VolumesInformation.Volumes[i].DirStringsCount; j++)
      //  {
      //    Console.WriteLine($" {pf.VolumesInformation.Volumes[i].DirectoryStrings[j].Dir}");
      //  }
      //}

      //Console.WriteLine();
      //Console.WriteLine("Modules loaded:");
      //for (int i = 0; i < pf.FileNames.FileNames.Count; i++)
      //{
      //  Console.WriteLine($"{i + 1}:\t{pf.FileNames.FileNames[i]}");
      //}
    }
    private void AnalyzeFile(string prefetchFile)
    {
      PrefetchFile pf = PrefetchFile.Load(prefetchFile);

      Console.WriteLine($"File: {Path.GetFullPath(prefetchFile)}");
      Console.WriteLine("Prefetch file is{0}compressed", (pf.Compressed) ? " " : " not ");

      Console.WriteLine($"Executable name: {pf.Header.ExecutableName}");
      Console.WriteLine();
      Console.WriteLine($"Run count: {pf.FileInformation.RunCount}");
      Console.WriteLine($"Last executed:");
      for (int i = 0; i < pf.FileInformation.LastRunTime.Length && i < pf.FileInformation.RunCount; i++)
      {
        Console.WriteLine($"  {pf.FileInformation.LastRunTimeDT[i]}");
      }

      Console.WriteLine();
      Console.WriteLine("File Reference:");
      for (int i = 0; i < pf.MetricsArray.FileReference.Length; i++)
        Console.WriteLine($"{pf.MetricsArray.FileReference[i]:X}");

      Console.WriteLine();
      Console.WriteLine("Volume information:");
      for (int i = 0; i < pf.FileInformation.VolumesCount; i++)
      {
        Console.WriteLine($" Volume name: {pf.VolumesInformation.Volumes[i].VolName}");
        Console.WriteLine($" Creation date: {pf.VolumesInformation.Volumes[i].VolCreationTime}");
        Console.WriteLine($" Serial number: {pf.VolumesInformation.Volumes[i].VolSerialNumber:X}");
        Console.WriteLine();
      }

      Console.WriteLine("Directory strings:");
      for (int i = 0; i < pf.FileInformation.VolumesCount; i++)
      {
        for (int j = 0; j < pf.VolumesInformation.Volumes[i].DirStringsCount; j++)
        {
          Console.WriteLine($" {pf.VolumesInformation.Volumes[i].DirectoryStrings[j].Dir}");
        }
      }

      Console.WriteLine();
      Console.WriteLine("Modules loaded:");
      for (int i = 0; i < pf.FileNames.FileNames.Count; i++)
      {
        Console.WriteLine($"{i + 1}:\t{pf.FileNames.FileNames[i]}");
      }
    }
  }

  public class CommandLineArguments
  {
    private OptionSet options;

    public CommandLineArguments()
    {
      this.options = new OptionSet() {
        { "analyze|a", "Analyze the file", x => this.Analyze = true },
        { "decompres|d", "Decompress the file", x => this.Decompress = true },
        { "dir=", "Path to the directory containing prefetch files", x => this.PFDir = x },
        { "file=|f=", "Path to the .pf file", x => this.PFFile = x },
        { "out=|o=", "Path to the decompressed .pf file (or directory, where the files are going to be stored, if you choose the /dir option)", x => this.OUTItem = x },
        { "sort", "Sort by date", x => this.Sort = true }
      };
    }

    public bool Analyze { get; set; }
    public bool Decompress { get; set; }
    public string PFDir { get; set; }
    public string PFFile { get; set; }
    public string OUTItem { get; set; }
    public bool Help { get; set; }
    public bool Debug { get; set; }
    public bool Sort {  get; set; }

    public void Parse(string[] args)
    {
      List<string> addr = this.options.Parse(args);

      if (Analyze)
      {
        if (string.IsNullOrEmpty(PFFile) && string.IsNullOrEmpty(PFDir))
        {
          Console.WriteLine("You need to specify file or directory to analyze.");
          this.Help = true;
        }
        if (!string.IsNullOrEmpty(PFFile) && !File.Exists(Path.GetFullPath(PFFile)))
        {
          Console.WriteLine($"Check if the file exists and try again: {PFFile}");
          this.Help = true;
        }
        if (!string.IsNullOrEmpty(PFDir) && !Directory.Exists(Path.GetFullPath(PFDir)))
        {
          Console.WriteLine($"Check if the directory exists and try again: {PFDir}");
          this.Help = true;
        }
      }
      else if (Decompress)
      {
        if ((string.IsNullOrEmpty(PFFile) && string.IsNullOrEmpty(PFDir)) || string.IsNullOrEmpty(OUTItem))
        {
          Console.WriteLine("You need to specify file or directory to decompress.");
          this.Help = true;
        }

        if (!string.IsNullOrEmpty(PFFile) && !File.Exists(Path.GetFullPath(PFFile)))
        {
          Console.WriteLine($"Check if the file exists and try again: {PFFile}");
          this.Help = true;
        }
        if (!string.IsNullOrEmpty(PFDir) && !Directory.Exists(Path.GetFullPath(PFDir)))
        {
          Console.WriteLine($"Check if the directory exists and try again: {PFDir}");
          this.Help = true;
        }
      }
      else
      {
        Console.WriteLine("You need to specify what to do: analyze or decompress the file or directory.");
        this.Help = true;
      }

    }

    public void ShowHelp()
    {
      Console.WriteLine("{0} by Michal Grzegorzewski, mgrzeg@cqure.pl", System.Diagnostics.Process.GetCurrentProcess().ProcessName);
      Console.WriteLine();
      Console.WriteLine("This tool allows you to inspect prefetch files. Additionaly you can decompress the file (Windows 10 and newer only) and analyze it manually.");
      Console.WriteLine(@"Usage: {0} /file /dir /out", System.Diagnostics.Process.GetCurrentProcess().ProcessName);
      Console.WriteLine("Available parameters:");
      this.options.WriteOptionDescriptions(Console.Out);
      Console.WriteLine();
      Console.WriteLine("Credits");
      Console.WriteLine("Prefetch file parsing based on Adam Witt & Joachim Metz works");
      Console.WriteLine("Argument parsing by NDesk.Options.");
    }
  }
}
