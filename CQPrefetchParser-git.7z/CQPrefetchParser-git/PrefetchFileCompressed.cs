﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic;
using System.IO;
using System.Runtime.InteropServices;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileCompressed
  {
    internal static byte[] Decompress(byte[] data)
    {
      dynamic Win32Functions = Win32.Win32Functions();

      byte[] header = null;
      byte[] compressed = null;

      UInt32 signature = 0;
      UInt32 decompressed_size = 0;
      UInt32 calgo = 0;
      UInt32 crcck = 0;
      UInt32 magic = 0;
      Int32 compressed_size = 0;
      UInt64 ntCompressBufferWorkSpaceSize = 0;
      UInt64 ntCompressFragmentWorkSpaceSize = 0;
      UInt32 ntstatus = 0;

      IntPtr ntCompressed = IntPtr.Zero;
      IntPtr ntDecompressed = IntPtr.Zero;
      byte[] ntDecompressedBytes = null;
      ulong ntFinalUncompressedSize = 0;
      IntPtr ntWorkspace = IntPtr.Zero;

      using (MemoryStream ms = new MemoryStream(data))
      {
        using (BinaryReader br = new BinaryReader(ms))
        {
          header = new byte[8];
          compressed = new byte[br.BaseStream.Length - 8];

          br.Read(header, 0, 8);
          signature = BitConverter.ToUInt32(header, 0);
          decompressed_size = BitConverter.ToUInt32(header, 4);

          calgo = (signature & 0x0F000000) >> 24;
          crcck = (signature & 0xF0000000) >> 28;
          magic = signature & 0x00FFFFFF;
          if (magic != 0x004d414d)
          {
            Console.WriteLine("Not a MAM file!");
            return null;
          }

          br.Read(compressed, 0, (int)br.BaseStream.Length - 8);

          if (crcck != 0)
          {
            //TODO
          }

          compressed_size = compressed.Length;
          ntstatus = Win32Functions.RtlGetCompressionWorkSpaceSize(calgo, ref ntCompressBufferWorkSpaceSize, ref ntCompressFragmentWorkSpaceSize);

          if (ntstatus != 0)
          {
            Console.WriteLine("Problem with RtlGetCompressionWorkSpaceSize");
            return null;
          }

          ntDecompressed = Marshal.AllocHGlobal((Int32)decompressed_size);
          ntDecompressedBytes = new byte[decompressed_size];
          ntCompressed = Marshal.AllocHGlobal(compressed_size);
          Marshal.Copy(compressed, 0, ntCompressed, compressed.Length);
          ntWorkspace = Marshal.AllocHGlobal((Int32)ntCompressFragmentWorkSpaceSize);

          ntstatus = Win32Functions.RtlDecompressBufferEx(calgo, ntDecompressed, decompressed_size, ntCompressed, compressed_size, ref ntFinalUncompressedSize, ntWorkspace);
          Marshal.Copy(ntDecompressed, ntDecompressedBytes, 0, (Int32)decompressed_size);

          return ntDecompressedBytes;
        }
      }
    }
  }

  public static class Win32
  {
    public static dynamic Win32Functions()
    {
      dynamic Win32Functions = new ExpandoObject();

      var RtlDecompressBufferExAddr = Win32.GetProcAddress("ntdll.dll", "RtlDecompressBufferEx");
      var RtlDecompressBufferExDelegate = Win32.GetDelegateType(typeof(UInt32), new Type[] { typeof(uint), typeof(IntPtr), typeof(uint), typeof(IntPtr), typeof(int), typeof(ulong).MakeByRefType(), typeof(IntPtr) });
      Win32Functions.RtlDecompressBufferEx = Marshal.GetDelegateForFunctionPointer(RtlDecompressBufferExAddr, RtlDecompressBufferExDelegate);

      var RtlGetCompressionWorkSpaceSizeAddr = Win32.GetProcAddress("ntdll.dll", "RtlGetCompressionWorkSpaceSize");
      var RtlGetCompressionWorkSpaceSizeDelegate = Win32.GetDelegateType(typeof(UInt32), new Type[] { typeof(uint), typeof(ulong).MakeByRefType(), typeof(ulong).MakeByRefType() });
      Win32Functions.RtlGetCompressionWorkSpaceSize = Marshal.GetDelegateForFunctionPointer(RtlGetCompressionWorkSpaceSizeAddr, RtlGetCompressionWorkSpaceSizeDelegate);

      return Win32Functions;
    }

    public static Type GetDelegateType(Type ReturnType, params Type[] Parameters)
    {
      var Domain = AppDomain.CurrentDomain;
      var DynAssembly = new System.Reflection.AssemblyName("ReflectedDelegate");
      var AssemblyBuilder = Domain.DefineDynamicAssembly(DynAssembly, System.Reflection.Emit.AssemblyBuilderAccess.Run);
      var ModuleBuilder = AssemblyBuilder.DefineDynamicModule("InMemoryModule", false);
      var TypeBuilder = ModuleBuilder.DefineType("MyDelegateType", TypeAttributes.Class | TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.AnsiClass | TypeAttributes.AutoClass, typeof(System.MulticastDelegate));
      var ConstructorBuilder = TypeBuilder.DefineConstructor(MethodAttributes.RTSpecialName | MethodAttributes.HideBySig | MethodAttributes.Public, System.Reflection.CallingConventions.Standard, Parameters);
      ConstructorBuilder.SetImplementationFlags(MethodImplAttributes.Runtime | MethodImplAttributes.Managed);
      var MethodBuilder = TypeBuilder.DefineMethod("Invoke", MethodAttributes.Public | MethodAttributes.HideBySig | MethodAttributes.NewSlot | MethodAttributes.Virtual, ReturnType, Parameters);
      MethodBuilder.SetImplementationFlags(MethodImplAttributes.Runtime | MethodImplAttributes.Managed);

      return TypeBuilder.CreateType();
    }

    public static IntPtr GetProcAddress(string Module, string Procedure)
    {
      var SystemAssemblies = AppDomain.CurrentDomain.GetAssemblies();
      Assembly SystemAssembly = null;
      foreach (var sa in SystemAssemblies)
      {
        if (sa.GlobalAssemblyCache && Path.GetFileName(sa.Location) == "System.dll")
        {
          SystemAssembly = sa;
          break;
        }
      }

      var UnsafeNativeMethods = SystemAssembly.GetType("Microsoft.Win32.UnsafeNativeMethods");
      var GetModuleHandle = UnsafeNativeMethods.GetMethod("GetModuleHandle");
      var GetProcAddressMethod = UnsafeNativeMethods.GetMethod("GetProcAddress", new Type[] { typeof(System.Runtime.InteropServices.HandleRef), typeof(string)});
      var Kern32Handle = (IntPtr)GetModuleHandle.Invoke(new object(), new object[] { Module });
      var tmpPtr = new IntPtr();
      var HandleRef = new System.Runtime.InteropServices.HandleRef(tmpPtr, Kern32Handle);
      return (IntPtr)GetProcAddressMethod.Invoke(new object(), new object[] { HandleRef, Procedure });
    }

  }

}
