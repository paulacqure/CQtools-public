﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileVolumesInformationWinXPHandler : PrefetchFileVolumesInformationHandler
  {
    public PrefetchFileVolumesInformationWinXPHandler(PrefetchFileVolumesInformation item) : base(item)
    {
    }
    public override void ReadFrom(BinaryReader reader)
    {
      reader.BaseStream.Position = Item.Parent.FileInformation.VolumesInformationOffset;
      PrefetchFileVolumeInformation tempPFVI = null;
      PrefetchFileVolumeInformationHandler tempPFVIH = null;
      for (int i = 1; i <= Item.Parent.FileInformation.VolumesCount; i++)
      {
        tempPFVI = new PrefetchFileVolumeInformation(Item);
        tempPFVIH = new PrefetchFileVolumeInformationWinXPHandler(tempPFVI);
        tempPFVIH.ReadFrom(reader, i);
        Item.Volumes.Add(tempPFVI);
      }
    }
  }
  class PrefetchFileVolumesInformationVistaOrSevenHandler : PrefetchFileVolumesInformationWinXPHandler
  {
    public PrefetchFileVolumesInformationVistaOrSevenHandler(PrefetchFileVolumesInformation item) : base(item)
    {
    }
    public override void ReadFrom(BinaryReader reader)
    {
      reader.BaseStream.Position = Item.Parent.FileInformation.VolumesInformationOffset;
      PrefetchFileVolumeInformation tempPFVI = null;
      PrefetchFileVolumeInformationHandler tempPFVIH = null;
      for (int i = 1; i <= Item.Parent.FileInformation.VolumesCount; i++)
      {
        tempPFVI = new PrefetchFileVolumeInformation(Item);
        tempPFVIH = new PrefetchFileVolumeInformationVistaOrSevenHandler(tempPFVI);
        tempPFVIH.ReadFrom(reader, i);
        Item.Volumes.Add(tempPFVI);
      }
    }
  }
  class PrefetchFileVolumesInformationWin8Handler : PrefetchFileVolumesInformationVistaOrSevenHandler
  {
    public PrefetchFileVolumesInformationWin8Handler(PrefetchFileVolumesInformation item) : base(item)
    {
    }
    public override void ReadFrom(BinaryReader reader)
    {
      reader.BaseStream.Position = Item.Parent.FileInformation.VolumesInformationOffset;
      PrefetchFileVolumeInformation tempPFVI = null;
      PrefetchFileVolumeInformationHandler tempPFVIH = null;
      for (int i = 1; i <= Item.Parent.FileInformation.VolumesCount; i++)
      {
        tempPFVI = new PrefetchFileVolumeInformation(Item);
        tempPFVIH = new PrefetchFileVolumeInformationWin8Handler(tempPFVI);
        tempPFVIH.ReadFrom(reader, i);
        Item.Volumes.Add(tempPFVI);
      }
    }
  }
  class PrefetchFileVolumesInformationWin10Handler : PrefetchFileVolumesInformationWin8Handler
  {
    public PrefetchFileVolumesInformationWin10Handler(PrefetchFileVolumesInformation item) : base(item)
    {
    }

    public override void ReadFrom(BinaryReader reader)
    {
      reader.BaseStream.Position = Item.Parent.FileInformation.VolumesInformationOffset;
      PrefetchFileVolumeInformation tempPFVI = null;
      PrefetchFileVolumeInformationHandler tempPFVIH = null;
      for (int i = 1; i <= Item.Parent.FileInformation.VolumesCount; i++)
      {
        tempPFVI = new PrefetchFileVolumeInformation(Item);
        tempPFVIH = new PrefetchFileVolumeInformationWin10Handler(tempPFVI);
        tempPFVIH.ReadFrom(reader, i);
        Item.Volumes.Add(tempPFVI);
      }
    }
  }
  class PrefetchFileVolumesInformationHandler : IBinaryReadable
  {
    protected PrefetchFileVolumesInformation Item { get; set; }

    public PrefetchFileVolumesInformationHandler(PrefetchFileVolumesInformation item)
    {
      Item = item;
      Item.Volumes = new List<PrefetchFileVolumeInformation>();
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
    }
  }
}
