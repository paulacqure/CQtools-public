﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CQPrefetchParser
{
  class PrefetchFileFileNamesWinXPHandler : PrefetchFileFileNamesHandler
  {
    public PrefetchFileFileNamesWinXPHandler(PrefetchFileFileNames item) : base(item)
    {
    }
  }
  class PrefetchFileFileNamesVistaOrSevenHandler : PrefetchFileFileNamesWinXPHandler
  {
    public PrefetchFileFileNamesVistaOrSevenHandler(PrefetchFileFileNames item) : base(item)
    {
    }
  }
  class PrefetchFileFileNamesWin8Handler : PrefetchFileFileNamesVistaOrSevenHandler
  {
    public PrefetchFileFileNamesWin8Handler(PrefetchFileFileNames item) : base(item)
    {
    }
  }
  class PrefetchFileFileNamesWin10Handler : PrefetchFileFileNamesWin8Handler
  {
    public PrefetchFileFileNamesWin10Handler(PrefetchFileFileNames item) : base(item)
    {
    }
  }
  class PrefetchFileFileNamesHandler : IBinaryReadable
  {
    protected PrefetchFileFileNames Item { get; set; }
    public PrefetchFileFileNamesHandler(PrefetchFileFileNames item)
    {
      Item = item;
      Item.FileNames = new List<string>();
    }

    public virtual void ReadFrom(BinaryReader reader)
    {
      Int64 currPos = reader.BaseStream.Position;
      string currFileName = string.Empty;

      do
      {
        currFileName = Utils.ReadNullTerminatedUnicodeString(reader);
        Item.FileNames.Add(currFileName);
        currFileName = string.Empty;
      }
      while (reader.BaseStream.Position < currPos + Item.Parent.FileInformation.FilenameStringsSize);
    }
  }
}
