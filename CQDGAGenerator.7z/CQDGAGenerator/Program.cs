﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using NDesk.Options;

//based on: https://en.wikipedia.org/wiki/Domain_generation_algorithm

namespace DGAGenerator
{
  class Program
  {
    static void Main(string[] args)
    {
      CommandLineArguments arguments = new CommandLineArguments();
      arguments.Parse(args);

      arguments.ShowHelp();

      if (!string.IsNullOrEmpty(arguments.To) && string.IsNullOrEmpty(arguments.From))
      {
        Console.WriteLine("Providing 'to' argument is not enough.");
        return;
      }

      try
      {
        DGAUrl(arguments.From, arguments.To, arguments.Fmt);
      }
      catch (Exception ex)
      {
        Console.WriteLine("Something went wrong: {0}", ex.Message);
      }
    }

    internal static void DGAUrl(string fromDate, string to, string fmt)
    {
      DateTime dtFrom = DateTime.Now;

      long year = dtFrom.Year;
      long month = dtFrom.Month;
      long day = dtFrom.Day;

      string tempDGA = string.Empty;

      if (string.IsNullOrEmpty(fmt)) fmt = "{0}";

      parseDate(fromDate, ref dtFrom);
      DateTime dtTo = dtFrom.AddDays(29);
      parseDate(to, ref dtTo);

      if (dtFrom >= dtTo) dtTo = dtFrom.AddDays(29);

      foreach (var date in IterateDates(dtFrom, dtTo))
      {
        year = date.Year;
        month = date.Month;
        day = date.Day;
        tempDGA = DGAGenerate(year, month, day);
        Console.WriteLine("Date: {0}, domain: {1}", date.ToShortDateString(), string.Format(fmt, tempDGA));
      }      
    }

    private static void parseDate(string strDate, ref DateTime date)
    {
      long year = 0;
      long month = 0;
      long day = 0;

      if (!string.IsNullOrEmpty(strDate) && strDate.Length == 10)
      {
        if (long.TryParse(strDate.Substring(0, 4), out year) &&
           long.TryParse(strDate.Substring(5, 2), out month) &&
           long.TryParse(strDate.Substring(8, 2), out day)
          )
        {
          if (month > 0 && month < 13 && day > 0 && day < 32)
          {
            date = new DateTime((int)year, (int)month, (int)day);
          }
        }
      }
    }

    internal static IEnumerable<DateTime> IterateDates(DateTime dfrom, DateTime to)
    {
      DateTime temp = dfrom;

      while (temp <= to)
      {
        yield return temp;
        temp = temp.AddDays(1);
      }
    }

    internal static string DGAGenerate(long year, long month, long day)
    {
      StringBuilder dga = new StringBuilder();

      for (int i = 0; i < 16; i++)
      {
        year = ((year ^ 8 * year) >> 11) ^ ((year & 0xFFFFFFF0) << 17);
        month = ((month ^ 4 * month) >> 25) ^ 16 * (month & 0xFFFFFFF8);
        day = ((day ^ (day << 13)) >> 19) ^ ((day & 0xFFFFFFFE) << 12);
        dga.Append((char)(((year ^ month ^ day) % 25) + 97));
      }
      return dga.ToString();
    }
  }

  public class CommandLineArguments
  {
    private OptionSet options;

    public CommandLineArguments()
    {
      this.options = new OptionSet() {
        { "fmt=", "Domain display format, eg: {{0}}.com", x => this.Fmt = x },
        { "from=", "Starting date, in format: yyyy-mm-dd. If 'to' param is omitted, 30 addresses are calculated, starting from 'from' date.", x => this.From = x },
        { "to=", "End date, in format: yyyy-mm-dd. Requires 'from' param.", x => this.To = x }
      };
    }

    //public string SID { get; set; }
    public string Fmt { get; set; }
    public string From { get; set; }
    public string To { get; set; }
    public bool Help { get; set; }
    public bool Debug { get; set; }


    public void Parse(string[] args)
    {
      List<string> addr = this.options.Parse(args);
      //if (string.IsNullOrEmpty(SID)) this.Help = true;
    }


    public void ShowHelp()
    {
      Console.WriteLine("{0} by Michal Grzegorzewski, mgrzeg@cqure.pl", System.Diagnostics.Process.GetCurrentProcess().ProcessName);
      Console.WriteLine();
      Console.WriteLine("Generator of domain addresess, based on the https://en.wikipedia.org/wiki/Domain_generation_algorithm, used by CryptoLocker");
      Console.WriteLine(@"Usage: {0} [/from /to]", System.Diagnostics.Process.GetCurrentProcess().ProcessName);
      Console.WriteLine("If run without params, produces 30 addresses, starting from today.");
      Console.WriteLine();
      Console.WriteLine("Available optional parameters:");
      this.options.WriteOptionDescriptions(Console.Out);
      Console.WriteLine();
      Console.WriteLine("Credits");
      Console.WriteLine("Argument parsing by NDesk.Options.");
      Console.WriteLine();
    }
  }

}
