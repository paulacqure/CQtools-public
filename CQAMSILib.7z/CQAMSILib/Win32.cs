﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

namespace AMSILib
{
    public class Win32
    {
    public enum COINIT
    {
      COINIT_APARTMENTTHREADED = 0x2,
      COINIT_MULTITHREADED = 0x0,
      COINIT_DISABLE_OLE1DDE = 0x4,
      COINIT_SPEED_OVER_MEMORY = 0x8
    };

    public enum AMSI_RESULT
    {
      AMSI_RESULT_CLEAN = 0,
      AMSI_RESULT_NOT_DETECTED = 1,
      AMSI_RESULT_DETECTED = 32768
    };
    
    [DllImport("ole32.dll")]
    public static extern UInt32 CoInitializeEx(IntPtr pvReserved, COINIT dwCoInit);

    [DllImport("ole32.dll")]
    public static extern UInt32 CoUninitialize();

    [DllImport("amsi.dll", EntryPoint = "AmsiInitialize", SetLastError = true)]
    public static extern UInt32 AmsiInitialize([MarshalAs(UnmanagedType.LPWStr)] string appName, out IntPtr amsiContext);
    [DllImport("amsi.dll", EntryPoint = "AmsiUninitialize", SetLastError = true)]
    public static extern UInt32 AmsiUninitialize(IntPtr amsiContext);
    [DllImport("amsi.dll", EntryPoint = "AmsiOpenSession", SetLastError = true)]
    public static extern UInt32 AmsiOpenSession(IntPtr amsiContext, out IntPtr session);
    [DllImport("amsi.dll", EntryPoint = "AmsiCloseSession", SetLastError = true)]
    public static extern UInt32 AmsiCloseSession(IntPtr amsiContext, IntPtr session);
    [DllImport("amsi.dll", EntryPoint = "AmsiScanString", SetLastError = true)]
    public static extern UInt32 AmsiScanString(IntPtr amsiContext, [MarshalAs(UnmanagedType.LPWStr)]string scannedString, [MarshalAs(UnmanagedType.LPWStr)]string contentName, IntPtr session, out AMSI_RESULT amsiResult);
    [DllImport("amsi.dll", EntryPoint = "AmsiResultIsMalware", SetLastError = true)]
    public static extern bool AmsiResultIsMalware(AMSI_RESULT result);

  }
}
