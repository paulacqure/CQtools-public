﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;

using AMSILib;

namespace AMSITester
{
  class Program
  {
   // [STAThread]
    static void Main(string[] args)
    {
      string appName = "CQAMSITester";
      string str2Scan = "AMSI Test Sample: 7e72c3ce-861b-4339-8740-0ac1484c13";// "ala ma kota";
      string contentName = "TestString";
      IntPtr amsiContext = IntPtr.Zero;
      IntPtr amsiSession = IntPtr.Zero;
      Win32.AMSI_RESULT amsiResult = Win32.AMSI_RESULT.AMSI_RESULT_CLEAN;

      UInt32 result = 0;
      //result = Win32.CoInitializeEx(IntPtr.Zero, Win32.COINIT.COINIT_APARTMENTTHREADED);
      result = Win32.AmsiInitialize(appName, out amsiContext);
      result = Win32.AmsiOpenSession(amsiContext, out amsiSession);

      result = Win32.AmsiScanString(amsiContext, str2Scan + "86", contentName, amsiSession, out amsiResult);
      //bool isMalware = Win32.AmsiResultIsMalware(amsiResult);

      if (amsiSession != IntPtr.Zero)
        result = Win32.AmsiCloseSession(amsiContext, amsiSession);
      if (amsiContext != IntPtr.Zero)
        result = Win32.AmsiUninitialize(amsiContext);
    }
  }
}
