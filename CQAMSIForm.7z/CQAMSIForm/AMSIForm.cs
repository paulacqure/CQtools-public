﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AMSILib;

namespace AMSIForm
{
  public partial class AMSIForm : Form
  {
    string appName = "AMSIForm";
    IntPtr amsiContext = IntPtr.Zero;
    IntPtr amsiSession = IntPtr.Zero;

    public AMSIForm()
    {
      InitializeComponent();
    }

    private void AMSIForm_Load(object sender, EventArgs e)
    {
      UInt32 result = 0;
      try
      {
        result = Win32.AmsiInitialize(appName, out amsiContext);
        result = Win32.AmsiOpenSession(amsiContext, out amsiSession);
      }
      catch(Exception ex)
      {

      }

    }

    private void textBoxAMSITest_TextChanged(object sender, EventArgs e)
    {
      string text2scan = textBoxAMSITest.Text;
      string contentName = "AMSI test form input";
      Win32.AMSI_RESULT amsiResult = Win32.AMSI_RESULT.AMSI_RESULT_CLEAN;

      try
      {
        UInt32 result = Win32.AmsiScanString(amsiContext, text2scan, contentName, amsiSession, out amsiResult);
      }
      catch(Exception ex)
      { }

      string resultText = "NOT DETECTED";
      switch(amsiResult)
      {
        case Win32.AMSI_RESULT.AMSI_RESULT_CLEAN:
          resultText = "CLEAN";
          break;

        case Win32.AMSI_RESULT.AMSI_RESULT_DETECTED:
          resultText = "DETECTED";
          break;

        default:
          resultText = "NOT DETECTED";
          break;
      }
      labelAMSIResult.Text = resultText;

    }

    private void AMSIForm_FormClosing(object sender, FormClosingEventArgs e)
    {
      UInt32 result = 0;
      try
      {
        if (amsiSession != IntPtr.Zero)
          result = Win32.AmsiCloseSession(amsiContext, amsiSession);
        if (amsiContext != IntPtr.Zero)
          result = Win32.AmsiUninitialize(amsiContext);
      }catch(Exception ex)
      { }

    }
  }
}
